Inline Anchor Styles
=========

A set of creative and modern inline anchor styles and effects for your inspiration.

[Article on Codrops](http://tympanus.net/codrops/?p=19205)

[Demo](http://tympanus.net/Development/InlineAnchorStyles/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is".

Arrow icon arrow_right.svg by [P.J. Onori](http://www.somerandomdude.com) licensed [CC BY-NC 3.0 NL](http://creativecommons.org/licenses/by-nc/3.0/nl/deed.en_GB)

Link icon from the [Feather icon set](https://gumroad.com/l/feather) by Cole Bemis licensed under [CC BY 3.0](http://creativecommons.org/licenses/by/3.0/)

Read more here: [License](http://tympanus.net/codrops/licensing/)

[© Codrops 2014](http://www.codrops.com)